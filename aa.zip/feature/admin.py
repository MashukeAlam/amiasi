from django.contrib import admin
from .models import Feature, FeatureConsumptionHistory

admin.site.register(Feature)
admin.site.register(FeatureConsumptionHistory)
